// oneclick — vi (placeholder)
// TODO: Translate from en/ version

