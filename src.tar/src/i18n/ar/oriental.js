// oriental — ar (placeholder)
// TODO: Translate from en/ version

