// oriental — ja (placeholder)
// TODO: Translate from en/ version

